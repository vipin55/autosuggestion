import React from "react";
import "./App.css";
import Chips  from "./component/chips/chip";

function App() {
  return (
    <div className="App">
      <Chips />
    </div>
  );
}

export default App;
